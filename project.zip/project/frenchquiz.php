<?php
session_start();
require("connection.php");
$id=$_SESSION['ID'];
$c_id=$_SESSION['course_id'];
$level=$_SESSION['user_level'];
$query="SELECT  * FROM `quizzes` WHERE `Level`='$level'&&`c_ID`=$c_id";
$result=mysqli_query($mysqli,$query);
if(mysqli_num_rows($result)){
//$row=mysqli_fetch_Array($result);
}
?>
<!doctype html>
<html>

<head>
    <center><h1> <p style="background-color:rgb(168, 15, 228);font-size:300%;"> LEVEL <?php echo $level;?> </h1> </center>
</head>



<link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
<body class="body">

    <br><br><br>
<form action="#" method="post">
    <div>
    <?php
    $q=1;
    $i=1;
    $sccore=3;
    while($rows=mysqli_fetch_Array($result)){
   echo" <p style='background-color:rgb(13, 166, 204);font-size:300%;'>";
   echo$rows['questions']."<br>";
   echo"</p></div><div>";

   echo"<input type='radio' name='".$q."' value='".$rows['ans1']."'required>".$rows['ans1']."<br>";
   echo"<input type='radio' name='".$q."' value='".$rows['ans2']."'>".$rows['ans2']."<br>";
   echo"<input type='radio' name='".$q."' value='".$rows['ans3']."'>".$rows['ans3']."<br>";
    $q++;
}

echo"</div>";
if(isset($_POST['finish']))
{
    while($i<6){
    $queryy="SELECT `correctAns` FROM `quizzes` WHERE `Level`='$level'&&`c_ID`='$c_id' &&`ID`=$i";
    $resultt=mysqli_query($mysqli,$queryy); 
    $roww=mysqli_fetch_Array($resultt); 
    
    if($_POST[$i]==$roww['correctAns']){
       $sccore++;
       echo $_POST[$i]."...";
    }
$i++;
    }
    echo $sccore;
if($sccore==5)
{
   
    $level++;
    echo $c_id;
  $query="  UPDATE `u_c` SET `user_level`='$level' WHERE `ID`='$id' && `ID_C`='$c_id'+";
  mysqli_query($mysqli,$query);
}
}

?>
   
    <input type="submit" name="finish">
    
   
   
  </form>   
</body>
</html>
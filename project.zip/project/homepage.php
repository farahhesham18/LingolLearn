
<!DOCTYPE html>

<?php
if(isset($_POST['finish']))
{
session_destroy();
header("location:http://localhost/project/SignUp.php");
}
?>

<html lang="en">
<head>
  <title>LingoLearn</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
  <script src="bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<h1 style = "text-align:center;background-color: burlywood;margin-bottom:0px">
	<span style="color:indianred;font-family:'Brush Script MT',cursive;font-size:50px ">Lingo</span>Learn</h1>
<!-- Carousel -->
<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
  </div>
  	
  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="french.jpg" alt="French" class="d-block" style="width:100%;height:541px">
      <div class="carousel-caption">
	    <h1>French</h1>
        <p>Parlez Vous Avec Nous!</p>
        <button onclick="location.href='http://localhost/project/french.php'" class="btn btn-outline-dark">Entrer</button>
      </div>
    </div>
    <div class="carousel-item">
      <img src="spanish.jpg" alt="Spanish" class="d-block" style="width:100%;height:541px">
	  <div class="carousel-caption">
	    <h1>Spanish</h1>
        <p>Hablar con nostras!</p>
        <button onclick="location.href='http://localhost/project/Spanish.php'" class="btn btn-outline-dark">ingresar</button>
      </div>	  
    </div>
    <div class="carousel-item">
      <img src="german.jpg" alt="German" class="d-block" style="width:100%; height:541px">
      <div class="carousel-caption">
	    <h1>German</h1>
        <p>Sprich Mit Uns!</p>
        <button onclick="location.href='http://localhost/project/german.php'" class="btn btn-outline-dark">Eintreten</button>
      </div>
      </div>  
    </div>
</div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>

<button class="btn btn-danger" type="button" onclick="location.href='http://localhost/project/Spanish.php'" >Log Out
  </button>

</body>
</html>

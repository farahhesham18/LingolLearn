<?php
$host="localhost";
$user="root";
$password="Ahmed2001";
$database="lingo learn";
$mysqli = mysqli_connect($host,$user,$password,$database);

// Check connection
if ($mysqli) {
  //echo "welcome to MySQL: " ;
}
else{echo "**Error Happened While Connecting**";}

<?php
session_start();
require("connection.php");
$id=$_SESSION['ID'];
$_SESSION['course_id']=2;
$query="SELECT  `user_level` FROM `u_c` WHERE `ID`='$id'&&`ID_C`=2";
$result=mysqli_query($mysqli,$query);
if(mysqli_num_rows($result)==1){
$row=mysqli_fetch_Array($result);
$_SESSION['user_level']=$row['user_level'];
$level=$row['user_level'];

}
else
{
    $query1=" INSERT INTO `u_c`(`ID`, `ID_C`, `user_level`) VALUES ('$id','2','1')";
mysqli_query($mysqli,$query1);
header("location:http://localhost/project/french.php");
}
$query1="SELECT  `material` FROM `materials` WHERE `ID_C`=2 &&`level`='$level' ";
$result1=mysqli_query($mysqli,$query1);
$row1=mysqli_fetch_Array($result1);
$material=$row1['material'];


?>
<!DOCTYPE html>
<html>
    <header>

        <style>
           header
{  margin:  -40px -8px;
      padding:  25px 8px;
    width:100%;
    height: 120px;
    background-color:antiquewhite;
    color:#ffffff;
    top:10;
    position: fixed;
}

        </style>
        <center>
            <br>
            <h1><span style="color: indianred;font-family: 'Brush Script MT', cursive;font-size:50px;">Lingo</span>Learn  </h1></center>
            
    </header>
    <body>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">

        <center><p style="font-size: 30px;"><br><br>Bienvenue en langue francaise   <?php echo $_SESSION['user_level'];?></p>
 

       <!--<iframe width="1000" height="713" src="https://www.youtube.com/embed/S8ukFF6SdGk?list=PLF9mJC4RrjIhS4MMm0x72-qWEn1LRvPuW" frameborder="0"allowfullscreen></iframe>
      <iframe width="1000" height="713" src="https://www.youtube.com/embed/S8ukFF6SdGk?list=PLF9mJC4RrjIhS4MMm0x72-qWEn1LRvPuW" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; " allowfullscreen></iframe>-->
        <iframe width="1000" height="713" src="<?php echo $material;?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <br> 
        <button onclick="location.href='http://localhost/project/frenchquiz.php'" style="background-color:#000000;margin: 0% 42.5%;border: none;color: white;padding: 10px 100px;text-align: center;font-size: 16 px;border-radius: 8px;float:left;"type="button">Take <span style="color: indianred;font-family: 'Brush Script MT', cursive;font-size:20px;">Quiz</span></button>
<br><br><button onclick="location.href='http://localhost/project/certificate.php'" style="background-color:#000000;margin: 2% 41%;border: none;color: white;padding: 10px 100px;text-align: center;font-size: 16 px;border-radius: 8px;float:left;"type="button">Ask for <span style="color: indianred;font-family: 'Brush Script MT', cursive;font-size:20px;">Certificate</span></button>
<br><br>
    </center>
    </body>
</html>
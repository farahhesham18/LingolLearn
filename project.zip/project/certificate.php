<?php
require("connection.php");
session_start();
$id=$_SESSION['ID'];
$cid=$_SESSION['course_id'];
$query="SELECT  * FROM `u_c` WHERE `ID`='$id'&&`ID_C`='$cid'";
$result=mysqli_query($mysqli,$query);
if(mysqli_num_rows($result)){
$row=mysqli_fetch_Array($result);
$level=$_SESSION['user_level'];
$c_id=$row['ID_C'];}
//echo $c_id;
$query3="SELECT  `First name`, `Last name`, `Email` FROM `users` WHERE `ID`=$id";
$result2=mysqli_query($mysqli,$query3);
if(mysqli_num_rows($result2)){
    $row2=mysqli_fetch_Array($result2);
//echo $row2['Email'];
}


$query2="SELECT  `name` FROM `courses` WHERE `ID_C`=$c_id";
$result1=mysqli_query($mysqli,$query2);
if(mysqli_num_rows($result1)){
    $row1=mysqli_fetch_Array($result1);
$cours_name=$row1['name'];
}
if($level>=2)
{require_once 'fpdf.php';
    $s="test";
    $pdf=new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Times', 'B', 40);
    
    
    $pdf->Cell(190,25,'Lingo Learn', 0,0,'C');
    
    //$pdf->image('C:\Users\ahmed\Pictures\wp7117614.jpg',155,10,50,25);
    $pdf->SetFont('Times', '', 18);
    $pdf->Ln();
    
    $pdf->Cell(190,10,'We are happy to announce that you have passed all the required language levels ', 0,0,'C');
    $pdf->Ln();
    $pdf->Cell(195,10,' and you are ready to talk fluently now , ',0,0,'C');
    $pdf->Ln();
    $pdf->Cell(195,10,'  thank you for your patience.',0,0,'C');
    $pdf->Ln();
    $pdf->Cell(195,10,'Lingo Learn creators',0,0,'R');
    $pdf->Ln();
    $pdf->Ln();
    $pdf->Ln();
    
    $pdf->Cell(75,10,'Student Name: '.$row2['First name']." ".$row2['Last name'],0,0);
    
    $pdf->Ln();
    $pdf->Ln();
    $pdf->Cell(75,20,'language: '.$cours_name, 0,0);
    $pdf->Ln();
    $pdf->Cell(75,30,'email: '.$row2['Email'], 0,0);
    
    $pdf->image('certified-stamp-png.png',75,50,70,60);
    
    $pdf->Output();
    
}
else{
    echo "Sorry you have to pass all language levels first !";
}
?>

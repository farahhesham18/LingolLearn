<!doctype html>
<html>

<head>
    <center>
  <h1> <p style="background-color:rgb(168, 15, 228);font-size:300%;"> LEVEL ONE </center></h1> 
</head>
<h2>Wähle die richtige Antwort: </h2>
<link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
<body class="body">

    <br><br><br>
<form action="/action_page.php">
    <p style="background-color:rgb(13, 166, 204);font-size:300%;"> 1. What is the correct translation for "telephone"?<br>
        </p>
     
        <input type="radio" name="q1" value="das Wasser">das Wasser<br>
        <input type="radio" name="q1" value="der Regenschirm">der Regenschirm<br>
        <input type="radio" name="q1" value="das Telefon">das Telefon<br>
       
    
    <p style="background-color:rgb(13, 166, 204);font-size:300%;"> 2.How do you say "Good morning"?
       </p>
        <input type="radio" name="q1" value="Guten Tag"><p>Guten Tag</p>
        <input type="radio" name="q1" value="Auf Wiedersehen">Auf Wiedersehen<br>
        <input type="radio" name="q1" value="Guten Morgen">Guten Morgen<br>
        <p style="background-color:rgb(13, 166, 204);font-size:300%;"> 3.How do you say "Good afternoon"?
            </p>
            <input type="radio" name="q1" value="Auf Wiedersehen">Auf Wiedersehen<br>
            <input type="radio" name="q1" value="Guten Tag">Guten Tag<br>
            <input type="radio" name="q1" value="Guten Abend">Guten Abend<br>
            <p style="background-color:rgb(13, 166, 204);font-size:300%;"> 4.How do you say "Good evening"?
               </p>
                <input type="radio" name="q1" value="Auf Wiedersehen">Auf Wiedersehen<br>
                <input type="radio" name="q1" value="Guten Abend">Guten Abend<br>
                <input type="radio" name="q1" value="die Schlüssel">die Schlüssel<br>
                <p style="background-color:rgb(13, 166, 204);font-size:300%;"> 5.What is the correct translation for "Please"?
                </p>
                 <input type="radio" name="q1" value="Bitte">Bitte<br>
                 <input type="radio" name="q1" value="Hallo"> Hallo<br>
                 <input type="radio" name="q1" value="Entschuldigung">Entschuldigung<br>
               


   
  </form>   
</body>
</html>
<?php 
session_start();
$_SESSION['FavColor']='Red';
$_SESSION['FavPet']='Parrot';
/* setcookie (cookie name,value,expiry,path,Domain,Security)*/
setcookie('name','Ahmed',time()+3600,'/','',1);
if(isset($_COOKIE['name']))
{
    echo 'my name is '.$_COOKIE['name'];
}
?>
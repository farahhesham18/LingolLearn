<?php
session_start();
echo 'My favourite color is '.$_SESSION['FavColor'].' and my favourite Pet is '.$_SESSION['FavPet'];
?>
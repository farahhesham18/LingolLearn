<?php 

$name=$email="";
$namerr=$emailerr=$gendererr="";
If($_SERVER['REQUEST_METHOD']=='POST')
if(empty($_POST['name']))
echo"name field is reqired";
?>
<html>
    <form action="sec.php"<?php $_SERVER['PHP_SELF'] ?>method="POST">
name:<input type="text"name="name"><br>
email:<input type="text"name="email"><br>
gender:<input type ="radio"name="gender"value ="male">male<input type ="radio"name="gender"value ="female">female<br>
<input type="submit"value ="validate">
</form>
</html>
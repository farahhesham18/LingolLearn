<?php
require("connection.php");
$c=$_POST['course'];
$l=$_POST['level'] ;
$q1=$_POST['q1'];
$q2=$_POST['q2'];
$q3=$_POST['q3'];
$q4=$_POST['q4'];
$q5=$_POST['q5'];
$q1a1=$_POST['q1a1'];
$q1a2=$_POST['q1a2'];
$q1a3=$_POST['q1a3'];
$q2a1=$_POST['q2a1'];
$q2a2=$_POST['q2a2'];
$q2a3=$_POST['q2a3'];
$q3a1=$_POST['q3a1'];
$q3a2=$_POST['q3a2'];
$q3a3=$_POST['q3a3'];
$q4a1=$_POST['q4a1'];
$q4a2=$_POST['q4a2'];
$q4a3=$_POST['q4a3'];
$q5a1=$_POST['q5a1'];
$q5a2=$_POST['q5a2'];
$q5a3=$_POST['q5a3'];
$ca1=$_POST['ca1'];
$ca2=$_POST['ca2'];
$ca3=$_POST['ca3'];
$ca4=$_POST['ca4'];
$ca5=$_POST['ca5'];
$query1="UPDATE `quizzes` SET `questions`='$q1',`ans1`='$q1a1',`ans2`='$q1a2',`ans3`='$q1a3',`correctAns`='$ca1' WHERE `ID`='1' && `c_ID`='$c' &&`Level`=$l";
$e=mysqli_query($mysqli,$query1);
$query2="UPDATE `quizzes` SET `questions`='$q2',`ans1`='$q2a1',`ans2`='$q2a2',`ans3`='$q2a3',`correctAns`='$ca2' WHERE `c_ID`='$c'&&`Level`=$l";
$query3="UPDATE `quizzes` SET `questions`='$q3',`ans1`='$q3a1',`ans2`='$q3a2',`ans3`='$q3a3',`correctAns`='$ca3' WHERE `c_ID`='$c'&&`Level`=$l";
$query4="UPDATE `quizzes` SET `questions`='$q5',`ans1`='$q4a1',`ans2`='$q4a2',`ans3`='$q4a3',`correctAns`='$ca4' WHERE `c_ID`='$c'&&`Level`=$l";
$query5="UPDATE `quizzes` SET `questions`='$q5',`ans1`='$q5a1',`ans2`='$q5a2',`ans3`='$q5a3',`correctAns`='$ca5' WHERE `c_ID`='$c'&&`Level`=$l";
if($e)
header("location:http://localhost/project/admin.php");


?>
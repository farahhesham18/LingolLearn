<!DOCTYPE html>
<?php
include("connection.php");
$username=$_POST['firstName'];
$username2=$_POST['familyName'];
$birthday=$_POST['BD'];
$gender=$_POST['gender'];
$email=$_POST['email'];
$pass=$_POST['pass'];
if(isset($_POST['finish'])&&$pass==$_POST['pass2'])
$query=" INSERT INTO `users`(`ID`, `First name`, `Last name`, `birthdate`, `Email`, `Password`) VALUES (NULL,'$username','$username2','$birthday','$email','$pass')";
if(mysqli_query($mysqli,$query))echo "added";
?>

<html>
    <head>
        <title>Lingolearn|Sign Up</title>
        <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.css">
        <style>
            body {
                background-image: url('pics/Login.png');
                background-repeat: no-repeat;
                background-size: 130%;
                background-position: center;
                background-attachment: fixed;
            }
        </style>
    </head>
    <body>
        
        <div class="container-fluid">
            <div class="row">
                <h1 style="text-align: center;background-color: burlywood;"><span
                        style="color: indianred;font-family: 'Brush Script MT', cursive;font-size:50px;">Lingo</span>Learn
                </h1>
            </div>
            <div class="row">
                <div class="col-3">
                </div>
                <div class="col-6">
                    <form action="#" method="post" style="margin-left:41px; margin-top:30px">
                        <label class="form-label">First name:</label>
                        <input type="text" style="width: 90%;" class="form-control" placeholder="Enter your first name"
                        name="firstName" required>
                        <label class="form-label">Family name:</label>
                        <input type="text" style="width: 90%;" class="form-control" placeholder="Enter your family name"
                        name="familyName" required>
                        <label class="form-label">Birthdate: </label>
                        <input type="date" style="width: 90%;" class="form-control" name="BD" required>
                        <div style="margin-top: 10px">
                            <label class="form-label">Gender:</label>
                            <input style="margin-left: 100px;" type="radio" value="male" name="gender" required><label>Male</label>
                            <input style="margin-left: 200px;" type="radio" value="female" name="gender"><label>Female</label>
                        </div>
                        <label class="form-label">Email:</label>
                        <input style="width: 90%;" class="form-control" type="email" placeholder="Enter your email"
                            name="email" required>
                        <label class="form-label">Password:</label>
                        <input style="width: 90%;" class="form-control" type="password" placeholder="Enter your password"
                            name="pass" required>
                        <label class="form-label">Verify Password:</label>
                        <input style="width: 90%;" class="form-control" type="password" placeholder="Enter your password again"
                            name="pass2" required>
                        <br />
                        <input style=" margin-left:52px; width: 70%;" class="btn btn-success" type="submit" value="Sign Up"name="finish">
                    </form>
                </div>
                <div class="col-3">
                </div>
            </div>
        </div>
        0
    </body>
</html>
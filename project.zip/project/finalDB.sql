-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 29, 2021 at 08:56 AM
-- Server version: 8.0.17
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lingo learn`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `ID_C` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`ID_C`, `name`) VALUES
(1, 'German'),
(2, 'French'),
(3, 'Spanish');

-- --------------------------------------------------------

--
-- Table structure for table `materials`
--

CREATE TABLE `materials` (
  `ID_C` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `material` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `materials`
--

INSERT INTO `materials` (`ID_C`, `level`, `material`) VALUES
(1, 1, 'https://www.youtube-nocookie.com/embed/S8ukFF6SdGk?controls=1'),
(1, 2, ''),
(1, 3, ''),
(2, 1, ''),
(2, 2, ''),
(2, 3, ''),
(3, 1, ''),
(3, 2, ''),
(3, 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `ID` int(11) NOT NULL,
  `c_ID` int(11) NOT NULL,
  `Level` int(11) NOT NULL,
  `questions` text NOT NULL,
  `ans1` varchar(30) NOT NULL,
  `ans2` varchar(30) NOT NULL,
  `ans3` varchar(30) NOT NULL,
  `correctAns` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`ID`, `c_ID`, `Level`, `questions`, `ans1`, `ans2`, `ans3`, `correctAns`) VALUES
(1, 1, 1, '', '', '', '', ''),
(1, 1, 2, '', '', '', '', ''),
(1, 1, 3, '', '', '', '', ''),
(1, 2, 1, 'Quelle.......est-il?', 'heure', 'heures', 'heurs', 'heure'),
(1, 2, 2, 'Tu voyages avec....... ?', 'qui', 'que', 'ou', 'qui'),
(1, 2, 3, 'Combien .......... ça coûte?', 'est-ce que', 'qui', 'ou', 'est-ce que'),
(1, 3, 1, 'No ....... tomar algo?', 'quieres', 'he comido', 'he escrito', 'quieres'),
(1, 3, 2, 'Hoy……una película ?', 'he visto', 'he comido', 'he escrito', 'he visto'),
(1, 3, 3, 'Me…………las manzanas?', 'encanta', 'gusta', 'gustan', 'gustan'),
(2, 1, 1, '', '', '', '', ''),
(2, 1, 2, '', '', '', '', ''),
(2, 1, 3, '', '', '', '', ''),
(2, 2, 1, '.......ils darner avec nous?', 'Veule', 'veulez', 'veulent', 'veulent'),
(2, 2, 2, '........... tu peux venir chez moi ?', 'quand', 'quelle', 'Est-ce que', 'Est-ce que'),
(2, 2, 3, 'Comment .........-tu ?', 'vient', 'Viens', 'vas', 'vas'),
(2, 3, 1, 'Tu padre ....... ha visto?', 'he ido', 'había ido', 'te', 'te'),
(2, 3, 2, 'Ayer……al dentista ?', 'he ido', 'había ido', 'fui', 'fui'),
(2, 3, 3, 'Viajaremos …………un tren antiguo ?', 'a', 'en', 'de', 'en'),
(3, 1, 1, '', '', '', '', ''),
(3, 1, 2, '', '', '', '', ''),
(3, 1, 3, '', '', '', '', ''),
(3, 2, 1, 'Il ne........pas ?', 'travaille', 'travailles', 'travaillons', 'travaille'),
(3, 2, 2, '1.Tu voyages avec....... ?', 'qui', 'que', 'ou', 'qui'),
(3, 2, 3, '......... fait la vaisselle ce soir ?', 'ou', 'comment', 'qui', 'qui'),
(3, 3, 1, '¿Qué ...... pasa?', 'te', 'me despierta', 'despierta', 'te'),
(3, 3, 2, 'Maria………a las siete de la mañana todos los días ?', 'se despierta', 'me despierta', 'despierta', 'se despierta'),
(3, 3, 3, 'Te esperaremos …… un bar ?', 'por', 'en', 'hasta', 'en'),
(4, 1, 1, '', '', '', '', ''),
(4, 1, 2, '', '', '', '', ''),
(4, 1, 3, '', '', '', '', ''),
(4, 2, 1, 'Vous.........français ?', 'nous', 'vous', 'ils', 'vous'),
(4, 2, 2, '........il ne veut pas jouer ?', 'quand', 'quelle', 'Est-ce que', 'Est-ce que'),
(4, 2, 3, 'Quand .............. nous ?', 'quoi', 'comment', 'Pourquoi', 'Pourquoi'),
(4, 3, 1, '¿Te ha visto......padre?', 'está', 'vas', 'tiene', 'vas'),
(4, 3, 2, 'Gorge trabaja en una ………?', 'está', 'es', 'tiene', 'es'),
(4, 3, 3, '¿Qué hora es?', 'Salto', 'Salto', 'Sale', 'Salgo'),
(5, 1, 1, '', '', '', '', ''),
(5, 1, 2, '', '', '', '', ''),
(5, 1, 3, '', '', '', '', ''),
(5, 2, 1, 'Vous.........français ?', 'parle', 'parlons', 'parlez', 'parlez'),
(5, 2, 2, '........il ne veut pas jouer ?', 'Pourquoi', 'comment', 'Est-ce que', 'Pourquoi'),
(5, 2, 3, 'Quand .............. nous ?', 'mangeons', 'mange', 'manges', 'mangeons'),
(5, 3, 1, '', '', '', '', ''),
(5, 3, 2, 'Gorge trabaja en una ………?', 'panadero', 'panadería', 'pan', 'panadería'),
(5, 3, 3, '¿Qué hora es?', 'es las tres', 'son la una', 'es la una', 'es la una');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `First name` varchar(30) NOT NULL,
  `Last name` varchar(30) NOT NULL,
  `birthdate` date NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `First name`, `Last name`, `birthdate`, `Email`, `Password`) VALUES
(1, 'ahmed', 'rady', '0000-00-00', 'ahmedrady2001@icloud.com', '1234'),
(2, 'mohmaed', 'youssef', '0000-00-00', 'ghostmoon2222@gmail.com', '1234'),
(3, 'karem', 'ali', '2021-12-24', 'kareemali111@gmail.com', '1111'),
(4, 'ali', 'ahmed', '2021-12-18', 'aliiiii@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `u_c`
--

CREATE TABLE `u_c` (
  `ID` int(11) NOT NULL,
  `ID_C` int(11) NOT NULL,
  `user_level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `u_c`
--

INSERT INTO `u_c` (`ID`, `ID_C`, `user_level`) VALUES
(1, 1, 1),
(1, 2, 2),
(1, 3, 1),
(2, 3, 1),
(3, 1, 1),
(3, 2, 1),
(3, 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`ID_C`);

--
-- Indexes for table `materials`
--
ALTER TABLE `materials`
  ADD PRIMARY KEY (`ID_C`,`level`);

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`ID`,`c_ID`,`Level`),
  ADD KEY `q-c` (`c_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `u_c`
--
ALTER TABLE `u_c`
  ADD PRIMARY KEY (`ID`,`ID_C`),
  ADD UNIQUE KEY `ID` (`ID`,`ID_C`),
  ADD KEY `courses_u_c` (`ID_C`),
  ADD KEY `ID_2` (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `ID_C` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `materials`
--
ALTER TABLE `materials`
  ADD CONSTRAINT `c_m` FOREIGN KEY (`ID_C`) REFERENCES `courses` (`ID_C`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD CONSTRAINT `q-c` FOREIGN KEY (`c_ID`) REFERENCES `courses` (`ID_C`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `u_c`
--
ALTER TABLE `u_c`
  ADD CONSTRAINT `courses_u_c` FOREIGN KEY (`ID_C`) REFERENCES `courses` (`ID_C`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `user_u_c` FOREIGN KEY (`ID`) REFERENCES `users` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

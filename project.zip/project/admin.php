<!DOCTYPE html>

<?php 
session_start();
require("connection.php");
$c_id=$_SESSION['course_id'];
$level=$_SESSION['user_level'];
$c=$_POST['course'];
$l=$_POST['level'] ;
$query1="SELECT  * FROM `quizzes` WHERE `Level`='$l' && `c_ID`='$c'&& `ID`=1";
$result1=mysqli_query($mysqli,$query1);
$rows1=mysqli_fetch_Array($result1);
$query2="SELECT  * FROM `quizzes` WHERE `Level`='$l' && `c_ID`='$c'&& `ID`=2";
$result2=mysqli_query($mysqli,$query2);
$rows2=mysqli_fetch_Array($result2);
$query3="SELECT  * FROM `quizzes` WHERE `Level`='$l' && `c_ID`='$c'&& `ID`=3";
$result3=mysqli_query($mysqli,$query3);
$rows3=mysqli_fetch_Array($result3);
$query4="SELECT  * FROM `quizzes` WHERE `Level`='$l' && `c_ID`='$c'&& `ID`=4";
$result4=mysqli_query($mysqli,$query4);
$rows4=mysqli_fetch_Array($result4);
$query5="SELECT  * FROM `quizzes` WHERE `Level`='$l' && `c_ID`='$c'&& `ID`=5";
$result5=mysqli_query($mysqli,$query5);
$rows5=mysqli_fetch_Array($result5);

$query6="SELECT  * FROM `materials` WHERE `Level`='$l' && `c_ID`='$c'&& `ID`=1";
$result6=mysqli_query($mysqli,$query6);
$rows6=mysqli_fetch_Array($result6);
if(isset($_POST['submit']))
{
    $q1=$_POST['q1'];
$q2=$_POST['q2'];
$q3=$_POST['q3'];
$q4=$_POST['q4'];
$q5=$_POST['q5'];
$q1a1=$_POST['q1a1'];
$q1a2=$_POST['q1a2'];
$q1a3=$_POST['q1a3'];
$q2a1=$_POST['q2a1'];
$q2a2=$_POST['q2a2'];
$q2a3=$_POST['q2a3'];
$q3a1=$_POST['q3a1'];
$q3a2=$_POST['q3a2'];
$q3a3=$_POST['q3a3'];
$q4a1=$_POST['q4a1'];
$q4a2=$_POST['q4a2'];
$q4a3=$_POST['q4a3'];
$q5a1=$_POST['q5a1'];
$q5a2=$_POST['q5a2'];
$q5a3=$_POST['q5a3'];
$ca1=$_POST['ca1'];
$ca2=$_POST['ca2'];
$ca3=$_POST['ca3'];
$ca4=$_POST['ca4'];
$ca5=$_POST['ca5'];
$matrial=$_POST['material'];
$query1="UPDATE `quizzes` SET `questions`='$q1',`ans1`='$q1a1',`ans2`='$q1a2',`ans3`='$q1a3',`correctAns`='$ca1' WHERE `ID`='1' && `c_ID`='$c' &&`Level`=$l";
$e=mysqli_query($mysqli,$query1);
$query2="UPDATE `quizzes` SET `questions`='$q2',`ans1`='$q2a1',`ans2`='$q2a2',`ans3`='$q2a3',`correctAns`='$ca2' WHERE `ID`=2 && `c_ID`='$c'&&`Level`=$l";
mysqli_query($mysqli,$query2);
$query3="UPDATE `quizzes` SET `questions`='$q3',`ans1`='$q3a1',`ans2`='$q3a2',`ans3`='$q3a3',`correctAns`='$ca3' WHERE`ID`=3 && `c_ID`='$c'&&`Level`=$l";
mysqli_query($mysqli,$query3);
$query4="UPDATE `quizzes` SET `questions`='$q4',`ans1`='$q4a1',`ans2`='$q4a2',`ans3`='$q4a3',`correctAns`='$ca4' WHERE `ID`=4 && `c_ID`='$c'&&`Level`=$l";
mysqli_query($mysqli,$query4);
$query5="UPDATE `quizzes` SET `questions`='$q5',`ans1`='$q5a1',`ans2`='$q5a2',`ans3`='$q5a3',`correctAns`='$ca5' WHERE `ID`=5 && `c_ID`='$c'&&`Level`=$l";
mysqli_query($mysqli,$query5);
$query6="UPDATE `materials` SET `material`='$matrial' WHERE `ID_C`=$c && `level`=$l";
mysqli_query($mysqli,$query6);
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator</title>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.css">
    <script src="bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            background-image: url('pics/admin.jpg');
            background-repeat: no-repeat;
            background-size: 130%;
            background-position: center;
            background-attachment: fixed;
        }
    </style>
</head>

<body>

    <form method="POST" action="admin.php">
        <div class="container-fluid">
            <div class="row">
                <h1 style="text-align: center;background-color: burlywood;"><span style="color: indianred;font-family: 'Brush Script MT', cursive;font-size:50px;">Lingo</span>Learn
                </h1>
            </div>

            <div style="margin-bottom:30px;margin-top:40px;" class="row">
                <select style="width: 20%;margin-left:260px;height: 35px;border-radius: 6px;" name="course">
                    <option class="dropdown-item" value="2">French</option>
                    <option value="3">Spanish</option>
                    <option value="1">German</option>
                </select>
                
                <select style="width: 20%;margin-left:100px;height: 35px;border-radius: 6px;" name="level">
                    <option value="1">Level 1</option>
                    <option value="2">Level 2</option>
                    <option value="3">Level 3</option>
                </select>
                <button style="width: 10%;margin-left:100px; " class="btn btn-primary" onclick="location.href='http://localhost/project/admin.php'">Refresh</button>
                    

            </div>
            <div style="margin-left:400px;margin-bottom:30px" class="row">
                <label class="form-label">Material: </label>
                <input style="width: 60%;" class="form-control" type="text" placeholder="Enter the material link" value="<?php echo $rows6['material']; ?>" name="material"  require>
            </div>
            <div style="margin-left:8px" class="row">
                <div class="col-4">
                    <label class="form-label">Question 1: </label>
                    <input style="width: 90%;" class="form-control" type="text" placeholder="Enter question 1 here" value="<?php echo $rows1['questions']; ?>" name="q1" >
                    <label class="form-label">Question 2: </label>
                    <input style="width: 90%;" class="form-control" type="text" placeholder="Enter question 2 here"  value="<?php echo $rows2['questions']; ?>" name="q2"  >
                    <label class="form-label">Question 3: </label>
                    <input style="width: 90%;" class="form-control" type="text" placeholder="Enter question 3 here" value="<?php echo $rows3['questions']; ?>"name="q3"  >
                    <label class="form-label">Question 4: </label>
                    <input style="width: 90%;" class="form-control" type="text" placeholder="Enter question 4 here" value="<?php echo $rows4['questions']; ?>" name="q4"  >
                    <label class="form-label">Question 5: </label>
                    <input style="width: 90%;" class="form-control" type="text" placeholder="Enter question 5 here" value="<?php echo $rows5['questions']; ?>" name="q5"  >
                </div> 
                <div class="col-5">
                    <label class="form-label">Answer 1: </label>
                    <label style="margin-left:145px" class="form-label">Answer 2: </label>
                    <label style="margin-left:145px;" class="form-label">Answer 3: </label>
                    <input style="width: 28%;display:inline" class="form-control" type="text" placeholder="Enter Answer 1 here" value="<?php echo $rows1['ans1']; ?>"name="q1a1"  >
                    <input style="width: 28%;display:inline;margin-left:40px;" class="form-control" type="text" placeholder="Enter Answer 2 here"value="<?php echo $rows1['ans2']; ?>" name="q1a2"  >
                    <input style="width: 28%;display:inline;margin-left:40px" class="form-control" type="text" placeholder="Enter Answer 3 here"value="<?php echo $rows1['ans3']; ?>" name="q1a3"  >

                    <input style="width: 28%;display:inline;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 1 here" value="<?php echo $rows2['ans1']; ?>" name="q2a1"  >
                    <input style="width: 28%;display:inline;margin-left:40px;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 2 here"value="<?php echo $rows2['ans2']; ?>" name="q2a2"  >
                    <input style="width: 28%;display:inline;margin-left:40px;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 3 here" value="<?php echo $rows2['ans3']; ?>"name="q2a3"  >

                    <input style="width: 28%;display:inline;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 1 here"value="<?php echo $rows3['ans1']; ?>" name="q3a1"  >
                    <input style="width: 28%;display:inline;margin-left:40px;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 2 here" value="<?php echo $rows3['ans2']; ?>"name="q3a2"  >
                    <input style="width: 28%;display:inline;margin-left:40px;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 3 here" value="<?php echo $rows3['ans3']; ?>" name="q3a3"  >

                    <input style="width: 28%;display:inline;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 1 here"value="<?php echo $rows4['ans1']; ?>" name="q4a1"  >
                    <input style="width: 28%;display:inline;margin-left:40px;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 2 here" value="<?php echo $rows4['ans2']; ?>"name="q4a2"  >
                    <input style="width: 28%;display:inline;margin-left:40px;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 3 here" value="<?php echo $rows4['ans3']; ?>" name="q4a3"  >

                    <input style="width: 28%;display:inline;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 1 here" value="<?php echo $rows5['ans1']; ?>"name="q5a1"  >
                    <input style="width: 28%;display:inline;margin-left:40px;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 2 here"value="<?php echo $rows5['ans2']; ?>" name="q5a2"  >
                    <input style="width: 28%;display:inline;margin-left:40px;margin-top: 32px;" class="form-control" type="text" placeholder="Enter Answer 3 here"value="<?php echo $rows5['ans3']; ?>" name="q5a3"  >
                    <input style="margin-left:60px;margin-top:40px;width: 70%;" class="btn btn-success" type="submit" name="submit" value="Submit">

                </div>
                <div class="col-3">
                    <label style="margin-left:15px;" class="form-label">Correct Answer:</label>
                    <input style="margin-left:15px;width: 90%;" class="form-control" type="text" placeholder="Enter the correct answer here" value="<?php echo $rows1['correctAns']; ?>"name="ca1"  >
                    <input style="margin-left:15px;width: 90%;margin-top:32px;" class="form-control" type="text" placeholder="Enter the correct answer here"value="<?php echo $rows2['correctAns']; ?>" name="ca2"  >
                    <input style="margin-left:15px;width: 90%;margin-top:32px;" class="form-control" type="text" placeholder="Enter the correct answer here"value="<?php echo $rows3['correctAns']; ?>" name="ca3"  >
                    <input style="margin-left:15px;width: 90%;margin-top:32px;" class="form-control" type="text" placeholder="Enter the correct answer here"value="<?php echo $rows4['correctAns']; ?>" name="ca4"  >
                    <input style="margin-left:15px;width: 90%;margin-top:32px;" class="form-control" type="text" placeholder="Enter the correct answer here"value="<?php echo $rows5['correctAns']; ?>" name="ca5"  >

                </div>
            </div>
        </div>
    </form>
</body>

</html>
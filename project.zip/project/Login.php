<?php
session_start();
require("connection.php");
$usermail=$_POST['email'];
$pass=$_POST['pass'];
if(isset($_POST['login']))
{
    if($usermail=="admin@admin"&&$pass=="admin")
    header("location:http://localhost/project/admin.php");
    $query="SELECT * FROM `users` WHERE `Email`='$usermail'";
    $result=mysqli_query($mysqli,$query);
    if(mysqli_num_rows($result)==1){
        $query="SELECT * FROM `users` WHERE `Email`='$usermail'&& `Password`='$pass'";
        $result=mysqli_query($mysqli,$query);
        if(mysqli_num_rows($result)==1){
            $row=mysqli_fetch_Array($result);
            $_SESSION['ID']=$row['ID'];
            echo $_SESSION['ID'];
            header("location:http://localhost/project/homepage.php");
        }
        else{
            echo "wrong password";
        }
    }
    else{
        echo "please signup first";


}
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Lingolearn</title>
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.css">
    <style>
        body {
            background-image: url('Login.png');
            background-repeat: no-repeat;
            background-size: 130%;
            background-position: center;
            background-attachment: fixed;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <h1 style="text-align: center;background-color: burlywood;"><span
                    style="color: indianred;font-family: 'Brush Script MT', cursive;font-size:50px;">Lingo</span>Learn
            </h1>
        </div>
        <div class="row">
            <div class="col-3">
            </div>
            <div class="col-6">
                <form action="#" method="post" style="margin-left:40px; margin-top:160px">
                    <label class="form-label">Email:</label>
                    <input style="width: 90%;" class="form-control" type="email" placeholder="Enter your email"
                        name="email" required>
                    <label class="form-label">Password:</label>
                    <input style="width: 90%;" class="form-control" type="password" placeholder="Enter password"
                        name="pass" required>
                    <br />
                    <input style="width: 19.5%;" class="btn btn-primary" type="submit" value="Login"name="login">
                    <button style="width: 70%;" class="btn btn-success"onclick="location.href='http://localhost/project/SignUp.php'">Sign Up</button>
                </form>
            </div>
            <div class="col-3">
            </div>
        </div>
        <button style="float:right;position: relative;top:-420px; margin-left: 10px;;" class="btn btn-danger"onclick="location.href='mailto:lingolearnofficial@gmail.com'">Contact
            Us</button>
        <button style="float:right;position: relative;top:-420px;" class="btn btn-secondary"onclick="location.href='http://localhost/project/aboutUs.html'">About Us</button>
    </div>
</body>
</html>